import java.lang.Math;

public class Circulo {
    private double raio = 0;

    public Circulo(double r){
        setRaio(r);
    }

    public void setRaio(double r){
        if(r>0) raio = r;
        else System.out.println("Raio deve ser maior que 0");
    }

    public double getRaio(){
        return raio;
     }
     
     public void Exibe(){
        System.out.printf("Raio: %f\n", getRaio());
     }

     public void CalcularDiametro(){
        System.out.printf("Diametro: %.2f\n", 2*raio);
     }
     public void CalcularArea(){
        System.out.printf("Area: %.2f\n", Math.PI * Math.pow(raio, 2));
     }

     public void CalcularCircunferencia(){
       System.out.printf("Circunferencia: %.2f\n",2 * Math.PI * raio);
     }
    
}
