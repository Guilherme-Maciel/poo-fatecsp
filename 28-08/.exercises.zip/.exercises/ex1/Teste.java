public class Teste{
    public static void main(String[] args) {
        Circulo c = new Circulo(4);
        c.Exibe();  
        c.CalcularArea();
        c.CalcularCircunferencia();
        c.CalcularDiametro();
    }

}