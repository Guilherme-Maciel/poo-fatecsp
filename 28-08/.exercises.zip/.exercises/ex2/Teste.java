package ex2;
public class Teste {
    public static void main(String[] args) {
        ContaCorrente c = new ContaCorrente(99999, "Sofia Mello", 1000);
        c.Deposito(100);
        c.Exibir();
        c.Saque(800);
        c.Exibir();
        c.Saque(200);
        c.Exibir();
        c.Saque(1);    
        c.Exibir();
        c.Saque(999);
    }
}
