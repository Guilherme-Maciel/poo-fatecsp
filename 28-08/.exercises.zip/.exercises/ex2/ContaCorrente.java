package ex2;

public class ContaCorrente {
    private int numeroConta;
    private String titular;
    private double saldo = 0;

    public ContaCorrente(int numeroConta, String titular, double saldo) {
        this.numeroConta = numeroConta;
        this.titular = titular;
        if(saldo>0)
            this.saldo = saldo;
    }
    public void Deposito(double saldo){
        this.saldo += saldo;
    }
    public void Saque(double saque){
        if(this.saldo >= saque)
            this.saldo -= saque;
        else
            System.out.println("Você não possui saldo suficiente.");
    }
    public void Exibir(){
        System.out.printf("Numero Conta: %d\n", this.numeroConta);
        System.out.printf("Titular: %s\n", this.titular);
        System.out.printf("Saldo: %.2f\n", this.saldo);
    }    
}
